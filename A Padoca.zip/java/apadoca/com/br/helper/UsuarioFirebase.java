package apadoca.com.br.helper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import apadoca.com.br.activity.Admin.AdminActivity;
import apadoca.com.br.activity.LoginActivity;
import apadoca.com.br.activity.User.UserActivity;
import apadoca.com.br.model.Usuario;
import dmax.dialog.SpotsDialog;

public class UsuarioFirebase {


    public static FirebaseUser getUsuarioAtual(){
        FirebaseAuth usuario  =  ConfiguraçaoFirebase.getFirebaseAutenticacao();
        return usuario.getCurrentUser();
    }



    public static void redirecionaUsuarioLogado(Activity activity){
         AlertDialog dialog;
        FirebaseUser user = getUsuarioAtual();
        if(user != null) {
            dialog = new SpotsDialog.Builder().setContext(activity).setMessage("Realizando Login").setCancelable(false).build();
            dialog.show();
            DatabaseReference usuarioReference = ConfiguraçaoFirebase.getFirebase()
                    .child("usuarios").child(getIdentificadorUsuario());

            usuarioReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    Usuario usuario = dataSnapshot.getValue(Usuario.class);
                    String tipoUsuario = usuario.getTipoUsuario();
                    if (tipoUsuario.equals("U")) {

                        activity.startActivity(new Intent(activity, UserActivity.class));
                        dialog.dismiss();
                    } else {
                        activity.startActivity(new Intent(activity, AdminActivity.class));
                        dialog.dismiss();
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }else{
            activity.startActivity(new Intent(activity, LoginActivity.class));
        }

    }

    public static String getIdentificadorUsuario(){
        return getUsuarioAtual().getUid();
    }

}
