package apadoca.com.br.helper;

public class Cadastro {

    private String nome;
    private String email;
    private String tel;
}
