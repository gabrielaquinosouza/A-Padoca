package apadoca.com.br.helper;

import java.text.NumberFormat;

public class ConvertDouble {
    public static double formtador(double x){
        NumberFormat nf = NumberFormat.getNumberInstance();
        nf.setMaximumFractionDigits(2);
        nf.setMaximumFractionDigits(2);
        String str =  nf.format(x);
        str = str.replaceAll(",",".");

        return  Double.parseDouble(str);
    }
}
