package apadoca.com.br.helper;

import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class ConfiguraçaoFirebase {

    public static DatabaseReference referenciaFirebase;
    public static FirebaseAuth referenciaAutenticacao;
    public static StorageReference referenciaStorage;

    public ConfiguraçaoFirebase() {
    }

    // Buscar Id do Usuario
    public static  String getIdUsuario(){
        FirebaseAuth autenticacao = getFirebaseAutenticacao();
        return autenticacao.getUid();
    }

    // Buscar Referencia do Firebase
    public static  DatabaseReference getFirebase() {
        if( referenciaFirebase == null){
            referenciaFirebase = FirebaseDatabase.getInstance().getReference();
        }
        return referenciaFirebase;

    }
    public static String token(){
       return FirebaseInstanceId.getInstance().getToken();
    }

    //Buscar Autenticaçao do Firebase
    public static  FirebaseAuth getFirebaseAutenticacao() {
        if( referenciaAutenticacao == null){
            referenciaAutenticacao = FirebaseAuth.getInstance();
         System.out.println(FirebaseInstanceId.getInstance().getToken());

         System.out.println("-----------------------------------");

        }
        return referenciaAutenticacao;

    }

   // Buscar referencia do Storage
    public static StorageReference getFirebaseStorage() {
        if( referenciaStorage == null){
            referenciaStorage = FirebaseStorage.getInstance().getReference();
        }
        return referenciaStorage;

    }

}
