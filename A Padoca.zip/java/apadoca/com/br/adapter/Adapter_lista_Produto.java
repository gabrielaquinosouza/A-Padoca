package apadoca.com.br.adapter;

import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

import apadoca.com.br.R;
import apadoca.com.br.model.Produto;


public class Adapter_lista_Produto extends RecyclerView.Adapter<Adapter_lista_Produto.MyViewHolder>{

    private List<Produto> produtos;
    private Context context;

    public Adapter_lista_Produto(List<Produto> produtos, Context context) {
        this.produtos = produtos;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemLista = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_lista_produto, parent, false);
        return new MyViewHolder(itemLista);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int i) {
        Produto produto = produtos.get(i);
        holder.nome.setText(produto.getNome());
        holder.descricao.setText(produto.getDescricao());
        holder.valor.setText(Double.toString(produto.getValor()) + " €");
        String urlFotos = produto.getImagem();
        Picasso.get().load(urlFotos).into(holder.imagem);
    }

    @Override
    public int getItemCount() {
        return produtos.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView nome;
        TextView descricao;
        TextView valor;
        ImageView imagem;

        public MyViewHolder(View itemView) {
            super(itemView);

            nome = itemView.findViewById(R.id.textNomeListaItem);
            descricao = itemView.findViewById(R.id.textQtdXValorListaItem);
            valor = itemView.findViewById(R.id.textTotalItem);
            imagem = itemView.findViewById(R.id.imagemlista);
        }
    }
}
