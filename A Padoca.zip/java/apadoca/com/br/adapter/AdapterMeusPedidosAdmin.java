package apadoca.com.br.adapter;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import apadoca.com.br.R;
import apadoca.com.br.model.ItemPedido;
import apadoca.com.br.model.Pedido;



public class AdapterMeusPedidosAdmin extends RecyclerView.Adapter<AdapterMeusPedidosAdmin.MyViewHolder> {

    private List<Pedido> pedidos;

    public AdapterMeusPedidosAdmin(List<Pedido> pedidos) {
        this.pedidos = pedidos;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemLista = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_pedidos, parent, false);
        return new MyViewHolder(itemLista);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int i) {

        Pedido pedido = pedidos.get(i);
        holder.nome.setText( pedido.getNome() );
        holder.endereco.setText( pedido.getEndereco() );
        holder.status.setText(pedido.getStatus());
        holder.valor.setText( Double.toString(pedido.getValor()) + " €" );
        holder.data.setText(pedido.getData());



    }

    @Override
    public int getItemCount() {
        return pedidos.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView nome;
        TextView endereco;
        TextView valor;
        TextView status;
        TextView data;

        public MyViewHolder(View itemView) {
            super(itemView);

            nome        = itemView.findViewById(R.id.textPedidoNome);
            endereco    = itemView.findViewById(R.id.textPedidoEndereco);
            valor =  itemView.findViewById(R.id.txtPedidoTotal);
            status = itemView.findViewById(R.id.txtPedidoStatus);
            data = itemView.findViewById(R.id.textData);
        }
    }

}
