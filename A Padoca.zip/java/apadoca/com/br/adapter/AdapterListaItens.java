package apadoca.com.br.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;



import java.util.List;

import apadoca.com.br.R;
import apadoca.com.br.model.ItemPedido;

public class AdapterListaItens extends   RecyclerView.Adapter<AdapterListaItens.MyViewHolder> {


    private List<ItemPedido> itemPedidos;
    private Context context;


    public AdapterListaItens(List<ItemPedido> itens, Context context) {
        this.itemPedidos = itens;
        this.context = context;
    }


    @NonNull
    @Override
    public AdapterListaItens.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View item = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_detalhes_pedido, parent, false);
        return new AdapterListaItens.MyViewHolder(item);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterListaItens.MyViewHolder holder, int position) {
     ItemPedido  itemPedido = itemPedidos.get(position);
     holder.Qtd.setText(Integer.toString(itemPedido.getQuantidade()));
     holder.nomeItem.setText(itemPedido.getNomeProduto());
     holder.Total.setText(Double.toString(itemPedido.getTotal()) + " €");
     if(itemPedido.getObrservacoes().isEmpty()){
         holder.layout.setVisibility(View.INVISIBLE);
        ViewGroup.LayoutParams  l = holder.layout.getLayoutParams();
        l.height =0;
        l.width =0;
        holder.layout.setLayoutParams(l);
     }else {
         holder.obser.setText(itemPedido.getObrservacoes());
     }
    }

    @Override
    public int getItemCount() {
        return itemPedidos.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView nomeItem;
        TextView Qtd;
        TextView Total;
        TextView obser;
        LinearLayout layout;

        public MyViewHolder(View itemView){
            super(itemView);

            nomeItem = itemView.findViewById(R.id.textMPNome);
            Qtd = itemView.findViewById(R.id.textMPQtd);
            Total = itemView.findViewById(R.id.textMPTotal);
            obser = itemView.findViewById(R.id.textMPDescricao);
            layout = itemView.findViewById(R.id.LDesc);


        }
    }
}
