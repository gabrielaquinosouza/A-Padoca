package apadoca.com.br.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

import apadoca.com.br.R;
import apadoca.com.br.model.Produto;

public class AdapterProdutos extends RecyclerView.Adapter<AdapterProdutos.MyViewHolder> {

    private List<Produto> produtos;
    private Context context;


    public AdapterProdutos(List<Produto> produtos, Context context) {
        this.produtos = produtos;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View item = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_produto, parent, false);
        return new MyViewHolder(item);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Produto produto = produtos.get(position);
        holder.nome.setText(produto.getNome());
        holder.descricao.setText(produto.getDescricao());
        holder.categoria.setText(produto.getCategoria());
        holder.valor.setText(Double.toString(produto.getValor()) + " €" );

        String urlFotos = produto.getImagem();
        Picasso.get().load(urlFotos).into(holder.imagem);

    }

    @Override
    public int getItemCount() {
        return produtos.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView nome;
        TextView descricao;
        TextView categoria;
        TextView valor;
        ImageView imagem;

        public MyViewHolder(View itemView){
           super(itemView);

           nome = itemView.findViewById(R.id.textNome);
           valor = itemView.findViewById(R.id.textTotalItem);
           descricao = itemView.findViewById(R.id.textDescricao);
           categoria = itemView.findViewById(R.id.textCategoria);
           imagem = itemView.findViewById(R.id.imagemlista);
        }
    }
}
