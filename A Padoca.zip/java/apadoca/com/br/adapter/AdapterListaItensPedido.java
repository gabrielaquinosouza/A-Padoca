package apadoca.com.br.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;
import apadoca.com.br.R;
import apadoca.com.br.helper.ConvertDouble;
import apadoca.com.br.model.ItemPedido;

import static apadoca.com.br.R.drawable.ic_delete_black_24dp;


public class AdapterListaItensPedido extends RecyclerView.Adapter<AdapterListaItensPedido.MyViewHolder>{

    private List<ItemPedido> itemPedidos;
    private Context context;
    private int qtd;
    private double valorPedido;
    private String valorConfigurado;
    private ConvertDouble conversor = new ConvertDouble();
    public AdapterListaItensPedido(List<ItemPedido> itens, Context context) {
        this.itemPedidos = itens;
        this.context = context;
    }

    @NonNull
    @Override
    public AdapterListaItensPedido.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View item = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_itens_pedido, parent, false);
        return new AdapterListaItensPedido.MyViewHolder(item);
    }


    @Override
    public void onBindViewHolder(@NonNull AdapterListaItensPedido.MyViewHolder holder, int position) {
        ItemPedido item = itemPedidos.get(position);
        holder.nomeItem.setText(item.getNomeProduto());
        holder.QtdXValor.setText(item.getQuantidade() +" X " + Double.toString(item.getPrecoUnico()) + " €");
        holder.Total.setText(Double.toString(item.getTotal()) + " €");
        holder.Contador.setText(String.valueOf(item.getQuantidade()));

        if(item.getQuantidade() ==1){
            holder.btnDiminuir.setImageResource(ic_delete_black_24dp);
        }

        holder.btnDiminuir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qtd = Integer.parseInt(holder.Contador.getText().toString());
                qtd--;
                if(qtd == 0){
                    item.removerItemPedido();

                }else
                if(qtd !=1){
                    holder.Contador.setText(Integer.toString(qtd));
                    valorPedido = conversor.formtador(qtd * item.getPrecoUnico());
                    valorConfigurado = Double.toString(valorPedido)+ " €";
                    holder.Total.setText(valorConfigurado);
                    holder.QtdXValor.setText(qtd +" X " + Double.toString(item.getPrecoUnico()) + " €");
                    holder.btnDiminuir.setImageResource(R.drawable.ic_remove_black_24dp);
                    item.setQuantidade(qtd);
                    item.setTotal(valorPedido);
                    item.Salvar();

                }else {
                    holder.Contador.setText(Integer.toString(qtd));
                    valorPedido = conversor.formtador(qtd * item.getPrecoUnico());;
                    valorConfigurado = Double.toString(valorPedido)+ " €";
                    holder.Total.setText(valorConfigurado);
                    holder.QtdXValor.setText(qtd +" X " + Double.toString(item.getPrecoUnico()) + " €");
                    holder.btnDiminuir.setImageResource(ic_delete_black_24dp);
                    item.setQuantidade(qtd);
                    item.setTotal(valorPedido);
                    item.Salvar();

                }


            }
        });
        holder.btnAumentar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                qtd = Integer.parseInt(holder.Contador.getText().toString());
                qtd++;
                if(qtd!=1){
                    holder.btnDiminuir.setImageResource(R.drawable.ic_remove_black_24dp);
                }
                holder.Contador.setText(Integer.toString(qtd));
                valorPedido =conversor.formtador(qtd * item.getPrecoUnico());
                System.out.println("Valor no Onclicl"+ valorPedido);
                valorConfigurado = Double.toString(valorPedido)+ " €";
                holder.Total.setText(valorConfigurado);
                holder.QtdXValor.setText(qtd +" X " + Double.toString(item.getPrecoUnico()) + " €");
                item.setQuantidade(qtd);
                item.setTotal(valorPedido);
                item.Salvar();
            }
        });





    }



    @Override
    public int getItemCount() {
        return itemPedidos.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView nomeItem;
        TextView QtdXValor;
        TextView Total;
        TextView Contador;
        FloatingActionButton btnAumentar;
        FloatingActionButton btnDiminuir;
        Drawable teste;
        public MyViewHolder(View itemView){
            super(itemView);

            nomeItem = itemView.findViewById(R.id.textNomeListaItem);
            QtdXValor = itemView.findViewById(R.id.textQtdXValorListaItem);
            Total = itemView.findViewById(R.id.textTotalItem);
            Contador = itemView.findViewById(R.id.txtContador);
            btnAumentar = itemView.findViewById(R.id.btnAumentarListaItem);
            btnDiminuir = itemView.findViewById(R.id.btnDiminuirListaItem);


        }
    }
}
