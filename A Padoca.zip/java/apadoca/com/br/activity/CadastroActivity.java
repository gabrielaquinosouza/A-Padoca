package apadoca.com.br.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;

import apadoca.com.br.R;
import apadoca.com.br.helper.ConfiguraçaoFirebase;
import apadoca.com.br.model.Usuario;
import dmax.dialog.SpotsDialog;

public class CadastroActivity extends AppCompatActivity {

    private TextInputEditText campoNome, campoEndereco, campoTelefone, campoEmail, campoSenha;
    private FirebaseAuth autenticacao;
    private ConfiguraçaoFirebase configUser = new ConfiguraçaoFirebase();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Cadastrar uma conta");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        campoNome = findViewById(R.id.editCadastroNome);
        campoEndereco = findViewById(R.id.editCadastroEndereco);
        campoTelefone = findViewById(R.id.editCadastroTelefone);
        campoEmail = findViewById(R.id.editCadastroEmail);
        campoSenha = findViewById(R.id.editCadastroSenha);
    }


    public void validarCadastroUsuario(View view){

        String nome = campoNome.getText().toString();
        String email = campoEmail.getText().toString();
        String senha = campoSenha.getText().toString();

        if(!nome.isEmpty()){
            if(!email.isEmpty()){
                if(!senha.isEmpty()){

                    Usuario usuario = new Usuario();
                    usuario.setNome(nome);
                    usuario.setEndereco(campoEndereco.getText().toString());
                    usuario.setTelefone(campoTelefone.getText().toString());
                    usuario.setEmail(email);
                    usuario.setSenha(senha);
                    usuario.setTipoUsuario("U");
                    usuario.setTokenUsuario(ConfiguraçaoFirebase.token());
                    cadastrarUsuario(usuario, this);

                }else{
                    Toast.makeText( CadastroActivity.this,
                            "Preencha o campo Senha!",
                            Toast.LENGTH_SHORT).show();
                }


            }else{
                Toast.makeText( CadastroActivity.this,
                        "Preencha o campo E-mail!",
                        Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText( CadastroActivity.this,
                    "Preencha o campo Nome!",
                    Toast.LENGTH_SHORT).show();
        }


    }
    public void cadastrarUsuario(Usuario usuario, Activity activity){
        AlertDialog dialog;
        dialog = new SpotsDialog.Builder().setContext(activity).setMessage("Realizando Cadastro").setCancelable(false).build();
        dialog.show();
        autenticacao = ConfiguraçaoFirebase.getFirebaseAutenticacao();
        autenticacao.createUserWithEmailAndPassword(usuario.getEmail(), usuario.getSenha()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){

                    try {
                        String idUsuario = task.getResult().getUser().getUid();
                        usuario.setId(idUsuario);
                        usuario.salvar();
                        dialog.dismiss();
                        finish();


                        startActivity(new Intent(CadastroActivity.this, Main_Activity.class));
                        Toast.makeText( CadastroActivity.this,
                                "Usuário Cadastrado com Sucesso!",
                                Toast.LENGTH_SHORT).show();
                        finish();
                    }catch (Exception e ){
                        dialog.dismiss();
                        e.printStackTrace();
                    }



                }else{
                    dialog.dismiss();
                    String erroExcecao = "";

                    try{
                        throw task.getException();
                    }catch (FirebaseAuthWeakPasswordException e){
                        erroExcecao = "Digite uma senha mais forte!";
                    }catch (FirebaseAuthInvalidCredentialsException e){
                        erroExcecao = "Por favor, digite um e-mail válido";
                    }catch (FirebaseAuthUserCollisionException e){
                        erroExcecao = "Este conta já foi cadastrada";
                    } catch (Exception e) {
                        erroExcecao = "ao cadastrar usuário: "  + e.getMessage();
                        e.printStackTrace();
                    }

                    Toast.makeText(CadastroActivity.this,
                            "Erro: " + erroExcecao ,
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
