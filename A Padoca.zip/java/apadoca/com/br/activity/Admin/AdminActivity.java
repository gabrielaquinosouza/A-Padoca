package apadoca.com.br.activity.Admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import apadoca.com.br.R;
import apadoca.com.br.activity.Main_Activity;
import apadoca.com.br.adapter.Adapter_lista_Produto;
import apadoca.com.br.helper.ConfiguraçaoFirebase;
import apadoca.com.br.model.Produto;
import apadoca.com.br.model.Usuario;
import dmax.dialog.SpotsDialog;

public class AdminActivity extends AppCompatActivity {
  private FirebaseAuth autenticacao;
    private Button buttonCategoria;
    private RecyclerView recyclerViewCliente;
    private DatabaseReference produtosRef;
    private List<Produto> listaprodutos = new ArrayList<>();
    private Adapter_lista_Produto adapter_lista_Produtos;
    private AlertDialog dialog;
    private String filtoCategoria;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        autenticacao = ConfiguraçaoFirebase.getFirebaseAutenticacao();
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("A Padoca -  Administração");
        setSupportActionBar(toolbar);

        inicializarComponentes();
        updateToken();
        produtosRef = ConfiguraçaoFirebase.getFirebase()
                .child("Produtos");
        recyclerViewCliente.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewCliente.setHasFixedSize(true);
        adapter_lista_Produtos = new Adapter_lista_Produto(listaprodutos, this);
        recyclerViewCliente.setAdapter(adapter_lista_Produtos);
        recuperarProdutos();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_administracao, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case  R.id.menuSair:
                deslogarUsuario();
                break;
            case R.id.menuMeusPedidos:
                listarMeusPedidos();
                break;
            case R.id.menuMeusProdutos:
                abrirNovoProduto();
                break;
            case R.id.menuCadastroAdmin:
                cadastrarAdmin();
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    public void listarMeusPedidos(){
        startActivity(new Intent(this, MeusPedidosActivity.class));
    }
    private void deslogarUsuario() {
        try {
            autenticacao.signOut();
            finish();
            startActivity(new Intent(this, Main_Activity.class));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void abrirNovoProduto(){
        startActivity(new Intent(AdminActivity.this, MeusProdutosActivity.class));
    }
    private void cadastrarAdmin(){
        startActivity(new Intent(AdminActivity.this, CadastroAdminActivity.class));
    }


    public void inicializarComponentes(){
        recyclerViewCliente = findViewById(R.id.recyclerItemPedido);
        buttonCategoria = findViewById(R.id.buttonCategoria);


    }


    public  void recuperarProdutos(){

        dialog = new SpotsDialog.Builder().setContext(this).setMessage("Listando Produtos").setCancelable(false).build();
        dialog.show();
        listaprodutos.clear();
        produtosRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                listaprodutos.clear();
                for (DataSnapshot Categorias: dataSnapshot.getChildren()){
                    for (DataSnapshot produtos: Categorias.getChildren()){
                        Produto produto = produtos.getValue(Produto.class);
                        listaprodutos.add(produto);


                    }
                }
                Collections.reverse(listaprodutos);
                adapter_lista_Produtos.notifyDataSetChanged();
                dialog.dismiss();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    public  void filtarProdutoCategoria(View view){
        AlertDialog.Builder dialogCategoria = new AlertDialog.Builder(this);
        dialogCategoria.setTitle("Selecione a Categoria");

        View viewSpinner = getLayoutInflater().inflate(R.layout.dialog_spiner, null);
        dialogCategoria.setView(viewSpinner);

        Spinner spinnerCategoria = viewSpinner.findViewById(R.id.spinnerFiltro);
        String[] categorias = getResources().getStringArray(R.array.categorias);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item,
                categorias);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategoria.setAdapter(adapter);

        dialogCategoria.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                filtoCategoria = spinnerCategoria.getSelectedItem().toString();

                recuperarProdutosCategoria();

            }
        });

        dialogCategoria.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        AlertDialog dialogFilto = dialogCategoria.create();
        dialogFilto.show();

    }

    public  void  recuperarProdutosCategoria() {
        produtosRef = ConfiguraçaoFirebase.getFirebase()
                .child("Produtos").child(filtoCategoria);
        dialog = new SpotsDialog.Builder().setContext(this).setMessage("Listando Produtos").setCancelable(false).build();
        dialog.show();
        listaprodutos.clear();
        produtosRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                listaprodutos.clear();
                for (DataSnapshot produtos : dataSnapshot.getChildren()) {
                    Produto produto = produtos.getValue(Produto.class);
                    listaprodutos.add(produto);

                }
                Collections.reverse(listaprodutos);
                adapter_lista_Produtos.notifyDataSetChanged();
                dialog.dismiss();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    public void updateToken(){
        Usuario Usuario = new Usuario();
        Usuario.updateAdmin(ConfiguraçaoFirebase.token());
    }
    }
