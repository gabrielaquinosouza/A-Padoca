package apadoca.com.br.activity.Admin;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import apadoca.com.br.helper.ConfiguraçaoFirebase;

import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import apadoca.com.br.R;
import apadoca.com.br.adapter.AdapterProdutos;
import apadoca.com.br.listener.RecyclerItemClickListener;
import apadoca.com.br.model.Produto;
import dmax.dialog.SpotsDialog;

public class MeusProdutosActivity extends AppCompatActivity {

    private RecyclerView recyclerProdutos;
    private List<Produto> produtos = new ArrayList<>();
    private AdapterProdutos adapterProdutos;
    private  DatabaseReference produtosRef;
    private AlertDialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meus_produtos);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Meus Produtos");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

         produtosRef = ConfiguraçaoFirebase.getFirebase()
                .child("meus_produtos");
        inicialzarComponentes();

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            startActivity(new Intent(MeusProdutosActivity.this, NovoProdutoActivity.class));
            }
        });
        recyclerProdutos.setLayoutManager(new LinearLayoutManager(this));
        recyclerProdutos.setHasFixedSize(true);
        adapterProdutos = new AdapterProdutos(produtos, this);
        recyclerProdutos.setAdapter(adapterProdutos);

        recuperarProdutos();

        recyclerProdutos.addOnItemTouchListener(
                new RecyclerItemClickListener(
                this, recyclerProdutos, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

            }

            @Override
            public void onLongItemClick(View view, int position) {

                Produto produtoSelecionado = produtos.get(position);
                produtoSelecionado.removerProduto(MeusProdutosActivity.this);
                adapterProdutos.notifyDataSetChanged();
                Toast.makeText( MeusProdutosActivity.this,
                        "Produto Excluído com Sucesso!",
                        Toast.LENGTH_SHORT).show();


            }

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        }
        ));
    }

    private  void recuperarProdutos(){
        dialog = new SpotsDialog.Builder().setContext(this).setMessage("Listando Produtos").setCancelable(false).build();
        dialog.show();
         produtosRef.addValueEventListener(new ValueEventListener() {
             @Override
             public void onDataChange(DataSnapshot dataSnapshot) {
                 produtos.clear();
                 for (DataSnapshot ds: dataSnapshot.getChildren()){
                     produtos.add(ds.getValue(Produto.class));
                 }
                 Collections.reverse(produtos);
                 adapterProdutos.notifyDataSetChanged();
                 dialog.dismiss();

             }

             @Override
             public void onCancelled(DatabaseError databaseError) {

             }
         });

    }

    public void inicialzarComponentes(){
        recyclerProdutos = findViewById(R.id.recicleProdutos);

    }
}
