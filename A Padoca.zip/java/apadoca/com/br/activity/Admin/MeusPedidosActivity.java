package apadoca.com.br.activity.Admin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import apadoca.com.br.R;
import apadoca.com.br.adapter.AdapterMeusPedidosAdmin;
import apadoca.com.br.helper.ConfiguraçaoFirebase;
import apadoca.com.br.listener.RecyclerItemClickListener;
import apadoca.com.br.model.Pedido;
import apadoca.com.br.model.Produto;
import dmax.dialog.SpotsDialog;

public class MeusPedidosActivity extends AppCompatActivity {
    private RecyclerView recyclerViewMeusPedidos;
    private AdapterMeusPedidosAdmin adapterAdmin;
    private List<Pedido> pedidos = new ArrayList<>();
    private AlertDialog alertDialog;
    private DatabaseReference firebaseRef;
    private Spinner spinerStatus;
    private DatabaseReference pedidoRef;
    private String filtroStatus;
    private AlertDialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meus_pedidos);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Meus Pedidos");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        carregarComponentes();
        firebaseRef = ConfiguraçaoFirebase.getFirebase();


        recyclerViewMeusPedidos.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewMeusPedidos.setHasFixedSize(true);
        adapterAdmin = new AdapterMeusPedidosAdmin(pedidos);
        recyclerViewMeusPedidos.setAdapter(adapterAdmin);

        configuracoesFiltro();
        recyclerViewMeusPedidos.addOnItemTouchListener(new RecyclerItemClickListener(this,
                recyclerViewMeusPedidos, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Pedido pedidoSelecionado = pedidos.get(position);
                Intent i = new Intent(MeusPedidosActivity.this, DetalhesPedidosActivity.class);
                i.putExtra("pedidoSelecionado", pedidoSelecionado );
                startActivity(i);

            }

            @Override
            public void onLongItemClick(View view, int position) {

            }

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        }) {
        });


    }

  public void  configuracoesFiltro(){
      String[] status = getResources().getStringArray(R.array.status);
      ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
              android.R.layout.simple_spinner_item,
              status);
      adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
      spinerStatus.setAdapter(adapter);
      spinerStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
          @Override
          public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            filtroStatus = spinerStatus.getItemAtPosition(position).toString();
              recuperarPedidosPorStatus();
          }

          @Override
          public void onNothingSelected(AdapterView<?> parent) {

          }
      });
    }


    public void carregarComponentes(){
        recyclerViewMeusPedidos = findViewById(R.id.RecycleMeusPedidos);
        spinerStatus = findViewById(R.id.spinnerStatus);

    }


    public  void  recuperarPedidosPorStatus(){
        pedidoRef = ConfiguraçaoFirebase.getFirebase()
                .child("pedido_status").child(filtroStatus);
        dialog = new SpotsDialog.Builder().setContext(this).setMessage("Listando Pedidos").setCancelable(false).build();
        dialog.show();
        pedidos.clear();
        pedidoRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                pedidos.clear();
                for (DataSnapshot pedidos_ref: dataSnapshot.getChildren()){
                    Pedido pedido = pedidos_ref.getValue(Pedido.class);
                    pedidos.add(pedido);

                }
                Collections.reverse(pedidos);
                adapterAdmin.notifyDataSetChanged();
                dialog.dismiss();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


    }
}
