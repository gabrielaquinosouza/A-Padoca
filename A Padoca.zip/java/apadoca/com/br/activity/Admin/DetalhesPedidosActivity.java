package apadoca.com.br.activity.Admin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import apadoca.com.br.R;
import apadoca.com.br.adapter.AdapterListaItens;
import apadoca.com.br.adapter.AdapterMeusPedidosAdmin;
import apadoca.com.br.helper.MyFirebaseMessagingService;
import apadoca.com.br.model.ItemPedido;
import apadoca.com.br.model.Pedido;
import apadoca.com.br.model.Produto;

public class DetalhesPedidosActivity extends AppCompatActivity {
    private RecyclerView recyclerViewDetalhesItens;
    private AdapterListaItens adapterAdmin;
    private List<ItemPedido> itens = new ArrayList<>();
    private Pedido pedidoSelecionado;
    private TextView txtNome, txtEdereco, txtTelemovel,txtTotal, txtTroco,txtdata;
    private RadioGroup status;
    private RadioButton Confirmacao, andamento, finalizado;
    private Pedido pedidoatual = new Pedido();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_pedidos);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        carregarComponentes();

        recyclerViewDetalhesItens.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewDetalhesItens.setHasFixedSize(true);
        adapterAdmin = new AdapterListaItens(itens, this);
        recyclerViewDetalhesItens.setAdapter(adapterAdmin);

        carregarItens();
    }

    public void carregarItens(){
        pedidoSelecionado = (Pedido) getIntent().getSerializableExtra("pedidoSelecionado");
        itens.clear();
        if(pedidoSelecionado != null){
            for(int i=0; i<pedidoSelecionado.getItens().size(); i++){
                ItemPedido item = pedidoSelecionado.getItens().get(i);
                itens.add(item);
            }
            Collections.reverse(itens);
            adapterAdmin.notifyDataSetChanged();
        }


        txtNome.setText(pedidoSelecionado.getNome());
        txtEdereco.setText(pedidoSelecionado.getEndereco());
        txtTelemovel.setText(pedidoSelecionado.getTelefone());
        //txtPagamento.setText("Pagamento: "+ pedidoSelecionado.getPagamento());
        txtTotal.setText(Double.toString(pedidoSelecionado.getValor()) + " €");
        txtTroco.setText(pedidoSelecionado.getTroco());
        txtdata.setText(pedidoSelecionado.getData());
        if(pedidoSelecionado.getStatus().equals(andamento.getText().toString())){
            andamento.setChecked(true);
            Confirmacao.setEnabled(false);
            finalizado.setEnabled(true);
        }else if(pedidoSelecionado.getStatus().equals(finalizado.getText().toString())){
            finalizado.setChecked(true);
            Confirmacao.setEnabled(false);
            andamento.setEnabled(false);
        }else{
            finalizado.setEnabled(false);
        }

       status.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
           @Override
           public void onCheckedChanged(RadioGroup group, int checkedId) {
              if(andamento.isChecked()){
                  Confirmacao.setEnabled(false);
                  finalizado.setEnabled(true);
                  pedidoatual.updatePedidos(pedidoSelecionado.getIdPedido(), andamento.getText().toString(), pedidoSelecionado.getIdUsuario());
                  MyFirebaseMessagingService.notificacao(pedidoSelecionado.getTokenUser(), 1);
                  pedidoSelecionado.setStatus(andamento.getText().toString());
                  pedidoatual.updatePedidoStatus(pedidoSelecionado.getIdPedido(),"Aguardando Confirmação",
                          andamento.getText().toString(), pedidoSelecionado.getIdUsuario(), pedidoSelecionado);
              }else if(finalizado.isChecked()){
                  Confirmacao.setEnabled(false);
                  andamento.setEnabled(false);
                  pedidoatual.updatePedidos(pedidoSelecionado.getIdPedido(), finalizado.getText().toString(), pedidoSelecionado.getIdUsuario());
                  MyFirebaseMessagingService.notificacao(pedidoSelecionado.getTokenUser(), 2);
                  pedidoSelecionado.setStatus(finalizado.getText().toString());
                  pedidoatual.updatePedidoStatus(pedidoSelecionado.getIdPedido(),"Em Andamento",
                          finalizado.getText().toString(), pedidoSelecionado.getIdUsuario(), pedidoSelecionado);

              }

           }
       });

    }

    public void carregarComponentes(){
        recyclerViewDetalhesItens = findViewById(R.id.recycleDetlhesIitens);
        txtNome = findViewById(R.id.txtPnome);
        txtEdereco = findViewById(R.id.txtPEndereco);
        txtTelemovel = findViewById(R.id.txtPTelemovel);
        txtTotal = findViewById(R.id.txtPTotal);
        txtTroco= findViewById(R.id.txtPTroco);
        txtdata = findViewById(R.id.txtPdata);
        status = findViewById(R.id.radioGroupStatus);
        Confirmacao = findViewById(R.id.radioConfirmacao);
        andamento = findViewById(R.id.radioAndamento);
        finalizado = findViewById(R.id.radioFinalizado);

    }
}
