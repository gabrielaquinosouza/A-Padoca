package apadoca.com.br.activity.Admin;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.blackcat.currencyedittext.CurrencyEditText;
import com.google.android.gms.auth.api.signin.internal.Storage;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.Locale;

import apadoca.com.br.R;
import apadoca.com.br.activity.LoginActivity;
import apadoca.com.br.helper.ConfiguraçaoFirebase;
import apadoca.com.br.model.Produto;
import apadoca.com.br.model.Usuario;
import dmax.dialog.SpotsDialog;

public class NovoProdutoActivity extends AppCompatActivity {
    private EditText nomePrdouto, descricaoProduto;
    private CurrencyEditText campoValor;
    private Spinner categoriaProduto;
    private ImageView imagemProduto;
    private StorageReference storage;
    private String localImg;
    private String UrlFotos;
    private AlertDialog dialog;
    private static  final int SELECAO_GALERIA = 200;
    private Produto produto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_novo_produto);
        storage = ConfiguraçaoFirebase.getFirebaseStorage();

        inicializarComponentes();
        carregarDadosSpinner();
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Novo Produto");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        imagemProduto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_PICK,
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                if(i.resolveActivity(getPackageManager()) != null ){
                    startActivityForResult(i, SELECAO_GALERIA);
                }
            }

        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            Bitmap imagem = null;

            try{
                switch (requestCode){
                    case SELECAO_GALERIA:
                        Uri localImagem = data.getData();
                        localImg = localImagem.toString();
                        imagem = MediaStore.Images.Media.getBitmap(getContentResolver(),localImagem);
                        break;


                }
                if(imagem !=null){
                    imagemProduto.setImageBitmap(imagem);
                }

            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
    private void carregarDadosSpinner(){
       // String[] categoria = new String[]{
           //"Padaria", "Pastelaria"
        //};
        String[] categorias = getResources().getStringArray(R.array.categorias);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item,
                categorias);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categoriaProduto.setAdapter(adapter);
    }

    private  void inicializarComponentes(){
        nomePrdouto = findViewById(R.id.editNomeProduto);
        descricaoProduto = findViewById(R.id.editDescricao);
        categoriaProduto = findViewById(R.id.spinnerCategoria);
        imagemProduto = findViewById(R.id.imagemProduto);
        campoValor =  findViewById(R.id.editTextValor1);

    }
    private Produto configurarProduto(){
        String nome = nomePrdouto.getText().toString();
        String descricao = descricaoProduto.getText().toString();
        String categoria = categoriaProduto.getSelectedItem().toString();
        long valor = campoValor.getRawValue();
        double conversao = (double) valor/100;;
        Produto produto = new Produto();
        produto.setNome(nome);
        produto.setCategoria(categoria);
        produto.setDescricao(descricao);
        produto.setValor(conversao);
        return produto;

    }




    private void salvarDadosProduto(){


       String l = localImg;
        if( l != null){
            dialog = new SpotsDialog.Builder().setContext(this).setMessage("Salvando Produto").setCancelable(false).build();
            dialog.show();
            salvarFotoStorage(l);
        }else{
            Toast.makeText( NovoProdutoActivity.this,
                    "Selecione a imagem do Produto",
                    Toast.LENGTH_SHORT).show();
        }

    }
    private void salvarFotoStorage(String c){

        StorageReference imagemProduto = storage.child( "imagens")
                .child( "Produtos").child( produto.getId());
        UploadTask up = imagemProduto.putFile(Uri.parse(c));
        up.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                if(taskSnapshot.getMetadata() != null){
                    if(taskSnapshot.getMetadata().getReference() != null){
                        Task<Uri> result = taskSnapshot.getStorage().getDownloadUrl();
                        result.addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                UrlFotos = uri.toString();
                                produto.setImagem(UrlFotos);
                                produto.salvar();
                                dialog.dismiss();
                                finish();
                            }
                        });
                    }
                }



            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                dialog.dismiss();
                Toast.makeText( NovoProdutoActivity.this,
                        "Erro ao fazer upload da Imagem",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void validarDadosProduto(View view){
      produto = configurarProduto();



        if( !produto.getNome().isEmpty()){
            if( !produto.getCategoria().isEmpty()){
                    if( produto.getValor() !=0 ){

                        salvarDadosProduto();
                    }else{
                        Toast.makeText( NovoProdutoActivity.this,
                                "Informe o valor do Produto",
                                Toast.LENGTH_SHORT).show();
                    }
            }else{
                Toast.makeText( NovoProdutoActivity.this,
                        "Informe a Categoria do Produto",
                        Toast.LENGTH_SHORT).show();
            }


        }else{
            Toast.makeText( NovoProdutoActivity.this,
                    "Preencha o campo  Nome",
                    Toast.LENGTH_SHORT).show();
        }

    }
}
