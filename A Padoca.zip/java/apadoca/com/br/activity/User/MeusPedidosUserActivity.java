package apadoca.com.br.activity.User;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import apadoca.com.br.R;
import apadoca.com.br.activity.Admin.DetalhesPedidosActivity;
import apadoca.com.br.adapter.AdapterMeusPedidosAdmin;
import apadoca.com.br.helper.ConfiguraçaoFirebase;
import apadoca.com.br.helper.UsuarioFirebase;
import apadoca.com.br.listener.RecyclerItemClickListener;
import apadoca.com.br.model.Pedido;
import dmax.dialog.SpotsDialog;

public class MeusPedidosUserActivity extends AppCompatActivity {
    private RecyclerView recyclerViewMeusPedidos;
    private DatabaseReference firebaseRef, pedidoRef;
    private AdapterMeusPedidosAdmin adapterAdmin;
    private List<Pedido> pedidos = new ArrayList<>();
    private AlertDialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meus_pedidos_user);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Meus Pedidos");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        carregarComponentes();
        firebaseRef = ConfiguraçaoFirebase.getFirebase();
        carregarPedidosUser();
        recyclerViewMeusPedidos.setLayoutManager(new LinearLayoutManager(MeusPedidosUserActivity.this));
        recyclerViewMeusPedidos.setHasFixedSize(true);
        adapterAdmin = new AdapterMeusPedidosAdmin(pedidos);
        recyclerViewMeusPedidos.setAdapter(adapterAdmin);



        recyclerViewMeusPedidos.addOnItemTouchListener(new RecyclerItemClickListener(this,
                recyclerViewMeusPedidos, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Pedido pedidoSelecionado = pedidos.get(position);
                Intent i = new Intent(MeusPedidosUserActivity.this, DetalhesMeusPedidosUserActivity.class);
                i.putExtra("pedidoUserSelecionado", pedidoSelecionado );
                startActivity(i);

            }

            @Override
            public void onLongItemClick(View view, int position) {

            }

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        }) {
        });


    }


    public void carregarPedidosUser(){

        pedidoRef = ConfiguraçaoFirebase.getFirebase()
                .child("meus_pedidos").child(UsuarioFirebase.getIdentificadorUsuario());
        dialog = new SpotsDialog.Builder().setContext(this).setMessage("Listando Pedidos").setCancelable(false).build();
        dialog.show();
        pedidos.clear();
        pedidoRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                pedidos.clear();
                for (DataSnapshot pedidos_ref: dataSnapshot.getChildren()){
                    Pedido pedido = pedidos_ref.getValue(Pedido.class);
                    pedidos.add(pedido);

                }
                Collections.reverse(pedidos);
                adapterAdmin.notifyDataSetChanged();
                dialog.dismiss();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    public void carregarComponentes(){
        recyclerViewMeusPedidos = findViewById(R.id.RecycleMeusPedidosUser);

    }
}
