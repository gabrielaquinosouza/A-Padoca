package apadoca.com.br.activity.User;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import apadoca.com.br.R;
import apadoca.com.br.adapter.AdapterListaItens;
import apadoca.com.br.model.ItemPedido;
import apadoca.com.br.model.Pedido;

public class DetalhesMeusPedidosUserActivity extends AppCompatActivity {
    private RecyclerView recyclerViewDetalhesItens;
    private TextView txtTotal, txtTroco,txtdata;
    private RadioButton Confirmacao, andamento, finalizado;
    private AdapterListaItens adapterAdmin;
    private List<ItemPedido> itens = new ArrayList<>();
    private Pedido pedidoSelecionado;
    private Button btnCancelar;
    private LinearLayout linearLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_meus_pedidos_user);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        carregarComponentes();

        recyclerViewDetalhesItens.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewDetalhesItens.setHasFixedSize(true);
        adapterAdmin = new AdapterListaItens(itens, this);
        recyclerViewDetalhesItens.setAdapter(adapterAdmin);

        carregarItens();
    }
    public void carregarItens(){
        pedidoSelecionado = (Pedido) getIntent().getSerializableExtra("pedidoUserSelecionado");
        itens.clear();
        if(pedidoSelecionado != null){
            for(int i=0; i<pedidoSelecionado.getItens().size(); i++){
                ItemPedido item = pedidoSelecionado.getItens().get(i);
                itens.add(item);
            }
            Collections.reverse(itens);
            adapterAdmin.notifyDataSetChanged();
        }

        txtTotal.setText(Double.toString(pedidoSelecionado.getValor()) + " €");
        txtTroco.setText(pedidoSelecionado.getTroco());
        txtdata.setText(pedidoSelecionado.getData());

        if(pedidoSelecionado.getStatus().equals(andamento.getText().toString())){
            andamento.setChecked(true);
            Confirmacao.setEnabled(false);
            finalizado.setEnabled(false);
        }else if(pedidoSelecionado.getStatus().equals(finalizado.getText().toString())){
            finalizado.setChecked(true);
            andamento.setEnabled(false);
            Confirmacao.setEnabled(false);
            btnCancelar.setEnabled(false);

        }else{
            Confirmacao.setChecked(true);
            finalizado.setEnabled(false);
            andamento.setEnabled(false);
        }
}
    public void carregarComponentes(){
        recyclerViewDetalhesItens = findViewById(R.id.recycleUserDetlhesIitens);
        txtTotal = findViewById(R.id.txtUserPTotal);
        txtTroco= findViewById(R.id.txtPUserTroco);
        txtdata = findViewById(R.id.txtUserPdata);
        Confirmacao = findViewById(R.id.radioUserConfirmacao);
        andamento = findViewById(R.id.radioUserAndamento);
        finalizado = findViewById(R.id.radioUserFinalizado);
        btnCancelar = findViewById(R.id.btnCancelar);
        linearLayout = findViewById(R.id.linearButton);
    }

    public void Chamartelefone (View view){
        Intent i = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", "123456789", null));
        startActivity(i);
    }
}
