package apadoca.com.br.activity.User;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import apadoca.com.br.R;
import apadoca.com.br.activity.CadastroActivity;
import apadoca.com.br.helper.ConfiguraçaoFirebase;
import apadoca.com.br.helper.UsuarioFirebase;
import apadoca.com.br.model.Usuario;

public class Configuracoes_User_Activity extends AppCompatActivity {
    private TextInputEditText editNome, editEndereco, editTelefone;
    private String idUsuario;
    private DatabaseReference firebaseRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuracoes__user_);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Configurações");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        inicializarComponentes();
        idUsuario = UsuarioFirebase.getIdentificadorUsuario();
        firebaseRef = ConfiguraçaoFirebase.getFirebase();
        recuperarDadosUsuario();
    }
    public void inicializarComponentes(){
        editNome = findViewById(R.id.editNomeUser);
        editEndereco = findViewById(R.id.editTextEndereco);
        editTelefone = findViewById(R.id.editTextTelefone);

    }

    private void  recuperarDadosUsuario(){
        DatabaseReference usuarioRef = firebaseRef
                .child( "usuarios")
                .child(idUsuario);

        usuarioRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Usuario usuario = dataSnapshot.getValue(Usuario.class);
                 editNome.setText(usuario.getNome());
                 editEndereco.setText(usuario.getEndereco());
                 editTelefone.setText(usuario.getTelefone());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public void  validarDadosUsuario(View view){
        String nome = editNome.getText().toString();
        String endereco = editEndereco.getText().toString();
        String telefone = editTelefone.getText().toString();

        if( !nome.isEmpty()){
            if(!endereco.isEmpty()){
                if(!telefone.isEmpty()){

                    DatabaseReference usuarioRef = firebaseRef
                            .child( "usuarios")
                            .child(idUsuario);

                    usuarioRef.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            Usuario usuario = dataSnapshot.getValue(Usuario.class);
                            Usuario usuarioSalvar = new Usuario();
                            usuarioSalvar.setId(idUsuario);
                            usuarioSalvar.setNome(nome);
                            usuarioSalvar.setTelefone(telefone);
                            usuarioSalvar.setEndereco(endereco);
                            usuarioSalvar.setEmail(usuario.getEmail());
                            usuarioSalvar.setTipoUsuario(usuario.getTipoUsuario());
                            usuarioSalvar.setSenha(usuario.getSenha());

                            usuarioSalvar.salvar();
                            exibirMensagem("Dados Atualizados com Sucesso!");
                            finish();
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });

                }else{
                    exibirMensagem("Informe o seu Telefone");
                }

            }else{
                exibirMensagem("Informe o seu Endereço");
            }

        }else{
            exibirMensagem("Informe o seu nome");
        }

    }

    private void exibirMensagem(String texto){
        Toast.makeText(this, texto, Toast.LENGTH_SHORT).show();
    }


}
