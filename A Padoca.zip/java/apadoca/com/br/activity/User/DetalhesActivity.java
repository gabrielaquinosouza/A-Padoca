package apadoca.com.br.activity.User;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.icu.text.SymbolTable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import apadoca.com.br.R;
import apadoca.com.br.helper.ConvertDouble;
import apadoca.com.br.model.ItemPedido;
import apadoca.com.br.model.Produto;

public class DetalhesActivity extends AppCompatActivity {
    private FloatingActionButton buttonDiminuir;
    private FloatingActionButton buttonAumentar;
    private TextView textValor;
    private EditText textObservacoes;
    private TextView textNomeDetalhe;
    private TextView textDescricaoDetalhe;
    private TextView textPrecoDetalhe;
    private ImageView imageDetalhe;
    private Produto produtoSeleciondado;
    private Button buttonAdcionar;
    private String valorConfigurado;
    private int qtd;
    private double valorPedido;
    private List<ItemPedido> listaItem = new ArrayList<>();
    private ConvertDouble conversor = new ConvertDouble();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Detalhes do item");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        inicalizarComponentes();

        produtoSeleciondado = (Produto) getIntent().getSerializableExtra("produtoseleciondo");
        if(produtoSeleciondado !=null){
            textNomeDetalhe.setText(produtoSeleciondado.getNome());
            textDescricaoDetalhe.setText(produtoSeleciondado.getDescricao());
            valorConfigurado = Double.toString(produtoSeleciondado.getValor())+ " €";
            textPrecoDetalhe.setText(valorConfigurado);
            String urlImage = produtoSeleciondado.getImagem();
            Picasso.get().load(urlImage).into(imageDetalhe);
            buttonAdcionar.setText("Adicionar        "+valorConfigurado);
            qtd = 1;
            valorPedido = produtoSeleciondado.getValor();


        }
        buttonDiminuir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qtd = Integer.parseInt(textValor.getText().toString());
                if(qtd !=1){
                    qtd--;
                    textValor.setText(Integer.toString(qtd));
                    valorPedido = conversor.formtador(qtd * produtoSeleciondado.getValor());
                    valorConfigurado = Double.toString(valorPedido)+ " €";
                    buttonAdcionar.setText("Adicionar        "+valorConfigurado);
                }

            }
        });
        buttonAumentar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qtd = Integer.parseInt(textValor.getText().toString());
                qtd++;
                textValor.setText(Integer.toString(qtd));
                valorPedido = conversor.formtador(qtd * produtoSeleciondado.getValor());

                valorConfigurado = Double.toString(valorPedido)+ " €";
                buttonAdcionar.setText("Adicionar        "+valorConfigurado);
            }
        });

    }

    public void adicionarCarrinho(View view){
        ItemPedido item = new ItemPedido();
        item.setIdProduto(produtoSeleciondado.getId());
        item.setNomeProduto(produtoSeleciondado.getNome());
        item.setObrservacoes(textObservacoes.getText().toString());
        item.setQuantidade(qtd);
        item.setTotal(valorPedido);
        item.setPrecoUnico(produtoSeleciondado.getValor());
        item.Salvar();
        startActivity(new Intent(this, UserActivity.class));
        Toast.makeText( DetalhesActivity.this,
                "Item adicionado ao carrinho",
                Toast.LENGTH_SHORT).show();
        finish();
    }


    public void inicalizarComponentes(){
        textNomeDetalhe = findViewById(R.id.textNomeListaItem);
        textDescricaoDetalhe = findViewById(R.id.textQtdXValorListaItem);
        textPrecoDetalhe = findViewById(R.id.textTotalItem);
        imageDetalhe = findViewById(R.id.imageViewDetalhes);
        buttonAumentar = findViewById(R.id.btnAumentarListaItem);
        buttonDiminuir = findViewById(R.id.btnDiminuirListaItem);
        textValor = findViewById(R.id.txtContador);
        buttonAdcionar = findViewById(R.id.buttonAdicionar);
        textObservacoes = findViewById(R.id.editTextObservacoes);
    }
}
