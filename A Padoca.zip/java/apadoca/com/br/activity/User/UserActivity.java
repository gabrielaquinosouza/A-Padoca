package apadoca.com.br.activity.User;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import apadoca.com.br.R;
import apadoca.com.br.activity.Main_Activity;
import apadoca.com.br.adapter.Adapter_lista_Produto;
import apadoca.com.br.helper.ConfiguraçaoFirebase;
import apadoca.com.br.helper.ConvertDouble;
import apadoca.com.br.listener.RecyclerItemClickListener;
import apadoca.com.br.helper.UsuarioFirebase;
import apadoca.com.br.model.ItemPedido;
import apadoca.com.br.model.Produto;
import dmax.dialog.SpotsDialog;

public class UserActivity extends AppCompatActivity {

    private RecyclerView recyclerViewCliente;
    private Button buttonCategoria, buttonCarrinho;
    private Adapter_lista_Produto adapter_lista_Produtos;
    private DatabaseReference produtosRef;
    private DatabaseReference RefItemPedido;
    private List<Produto> listaprodutos = new ArrayList<>();
    private AlertDialog dialog;
    private FirebaseAuth autenticacao;
    private String filtoCategoria;
    private List<ItemPedido> itensCarrinho = new ArrayList<>();
    private ItemPedido itemAdicionado;
    private double totalCarrinho;
    private ConvertDouble conversor = new ConvertDouble();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        autenticacao = ConfiguraçaoFirebase.getFirebaseAutenticacao();
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Produtos");
        setSupportActionBar(toolbar);

        produtosRef = ConfiguraçaoFirebase.getFirebase()
                .child("Produtos");

        inicializarComponentes();
        RecuperaValorTotal();

        recyclerViewCliente.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewCliente.setHasFixedSize(true);
        adapter_lista_Produtos = new Adapter_lista_Produto(listaprodutos, this);
        recyclerViewCliente.setAdapter(adapter_lista_Produtos);
        recuperarProdutos();

        recyclerViewCliente.addOnItemTouchListener(
                new RecyclerItemClickListener(this,
                        recyclerViewCliente,
                        new RecyclerItemClickListener.OnItemClickListener() {
                            @Override
                            public void onItemClick(View view, int position) {
                                Produto produtoSelecionado = listaprodutos.get(position);
                                Intent i = new Intent(UserActivity.this, DetalhesActivity.class);
                                i.putExtra("produtoseleciondo", produtoSelecionado );
                                startActivity(i);
                            }

                            @Override
                            public void onLongItemClick(View view, int position) {

                            }

                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                            }
                        })
        );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_usuario, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case  R.id.menuSair:
                deslogarUsuario();
                break;
            case R.id.menuConfiguracoes:
                configuracoUser();
                break;
            case R.id.menuMeusPedidosUser:
                meusPedidosUser();
        }
        return super.onOptionsItemSelected(item);
    }
    private void deslogarUsuario() {
        try {
            autenticacao.signOut();
            finish();
            startActivity(new Intent(this, Main_Activity.class));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

   public void  configuracoUser(){
        startActivity(new Intent(UserActivity.this, Configuracoes_User_Activity.class));

    }

    public void meusPedidosUser(){
        startActivity(new Intent(this, MeusPedidosUserActivity.class));
    }
    public void verItensPedido(View view){
        startActivity(new Intent(this, Realizar_PedidoActivity.class));
    }


    public  void filtarProdutoCategoria(View view){
        AlertDialog.Builder dialogCategoria = new AlertDialog.Builder(this);
        dialogCategoria.setTitle("Selecione a Categoria");

        View viewSpinner = getLayoutInflater().inflate(R.layout.dialog_spiner, null);
        dialogCategoria.setView(viewSpinner);

        Spinner spinnerCategoria = viewSpinner.findViewById(R.id.spinnerFiltro);
        String[] categorias = getResources().getStringArray(R.array.categorias);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item,
                categorias);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategoria.setAdapter(adapter);

        dialogCategoria.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                filtoCategoria = spinnerCategoria.getSelectedItem().toString();

                recuperarProdutosCategoria();

            }
        });

        dialogCategoria.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        AlertDialog dialogFilto = dialogCategoria.create();
        dialogFilto.show();

    }

   public void RecuperaValorTotal(){
       DatabaseReference firebaseReference = ConfiguraçaoFirebase.getFirebase();

       RefItemPedido = firebaseReference.child("itemPedido")
               .child(UsuarioFirebase.getIdentificadorUsuario());
       RefItemPedido.addValueEventListener(new ValueEventListener() {
           @Override
           public void onDataChange(DataSnapshot dataSnapshot) {
               totalCarrinho=0.0;
               for (DataSnapshot itemPedido:dataSnapshot.getChildren()){
                   ItemPedido  item  = itemPedido.getValue(ItemPedido.class);
                   totalCarrinho = totalCarrinho+item.getTotal();
               }

                   totalCarrinho = conversor.formtador(totalCarrinho) ;


               buttonCarrinho.setText("                   Ver Carrinho                        "+Double.toString(totalCarrinho)+" €");
               if(totalCarrinho == 0){
                   buttonCarrinho.setEnabled(false);
                   buttonCarrinho.setText("Carrinho Vazio         ");
                   buttonCarrinho.setGravity(Gravity.CENTER);
               }
           }

           @Override
           public void onCancelled(DatabaseError databaseError) {

           }
       });
   }
    public  void  recuperarProdutosCategoria(){
        produtosRef = ConfiguraçaoFirebase.getFirebase()
                .child("Produtos").child(filtoCategoria);
        dialog = new SpotsDialog.Builder().setContext(this).setMessage("Listando Produtos").setCancelable(false).build();
        dialog.show();
        listaprodutos.clear();
        produtosRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                listaprodutos.clear();
                    for (DataSnapshot produtos: dataSnapshot.getChildren()){
                        Produto produto = produtos.getValue(Produto.class);
                        listaprodutos.add(produto);

                }
                Collections.reverse(listaprodutos);
                adapter_lista_Produtos.notifyDataSetChanged();
                dialog.dismiss();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


    }


    public  void recuperarProdutos(){

        dialog = new SpotsDialog.Builder().setContext(this).setMessage("Listando Produtos").setCancelable(false).build();
        dialog.show();
        listaprodutos.clear();
        produtosRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                listaprodutos.clear();
                for (DataSnapshot Categorias: dataSnapshot.getChildren()){
                    for (DataSnapshot produtos: Categorias.getChildren()){
                        Produto produto = produtos.getValue(Produto.class);
                        listaprodutos.add(produto);


                    }
                }
                Collections.reverse(listaprodutos);
                adapter_lista_Produtos.notifyDataSetChanged();
                dialog.dismiss();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    public void inicializarComponentes(){
        recyclerViewCliente = findViewById(R.id.recyclerItemPedido);
        buttonCategoria = findViewById(R.id.buttonCategoria);
        buttonCarrinho = findViewById(R.id.btnCarrinho);


    }
}
