package apadoca.com.br.activity.User;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.sql.Ref;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import apadoca.com.br.R;
import apadoca.com.br.activity.Admin.AdminActivity;
import apadoca.com.br.activity.Admin.MeusProdutosActivity;
import apadoca.com.br.activity.Main_Activity;
import apadoca.com.br.adapter.AdapterListaItensPedido;
import apadoca.com.br.helper.ConfiguraçaoFirebase;
import apadoca.com.br.helper.ConvertDouble;
import apadoca.com.br.helper.MyFirebaseMessagingService;
import apadoca.com.br.helper.Permissoes;
import apadoca.com.br.helper.UsuarioFirebase;
import apadoca.com.br.model.ItemPedido;
import apadoca.com.br.model.Pedido;
import apadoca.com.br.model.Usuario;


public class Realizar_PedidoActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private AdapterListaItensPedido adapterListaItensPedido;
    private List<ItemPedido> listaItemPedido = new ArrayList<>();
    private List<ItemPedido> listaCarrinho = new ArrayList<>();
    private DatabaseReference RefItemPedido, RefUsuario, RefToken;
    private double totalCarrinho;
    private TextView txtValorTotal;
    private TextInputEditText telemovel, endereco, troco;
    private RadioButton dinheiro, maquina;
    private RadioGroup groupPagamento;
    private TextInputLayout layoutTroco;
    private String metodoPagamento;
    private String nomeUsuario;
    private SimpleDateFormat formaador;
    private Date data;
    private String dataFormatada;
    private ConvertDouble conversor = new ConvertDouble();
    private String tokenAdmin;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private String enderecoGps;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_realizar__pedido);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        inicializarComponentes();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        adapterListaItensPedido = new AdapterListaItensPedido(listaItemPedido, this);
        recyclerView.setAdapter(adapterListaItensPedido);
        recupreraItensPedido();
        RecuperaValorTotal();
        RefUsuario = ConfiguraçaoFirebase.getFirebase();

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_carrinho, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case  R.id.menuConfirmarPedido:
                confirmarPedido();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void confirmarPedido(){
        AlertDialog.Builder dialogConfirmar = new AlertDialog.Builder(this);
        View viewConfirmacaoPedido = getLayoutInflater().inflate(R.layout.dialog_confirmar_pedido, null);
        telemovel = viewConfirmacaoPedido.findViewById(R.id.Telemovel);
        endereco = viewConfirmacaoPedido.findViewById(R.id.EnderecoInputer);
        troco = viewConfirmacaoPedido.findViewById(R.id.troco);
        dinheiro = viewConfirmacaoPedido.findViewById(R.id.radioButtonDinheiro);
        maquina = viewConfirmacaoPedido.findViewById(R.id.radioButtonMC);
        groupPagamento =viewConfirmacaoPedido.findViewById(R.id.groupPagamento);
        layoutTroco = viewConfirmacaoPedido.findViewById(R.id.layoutTroco);
        dialogConfirmar.setView(viewConfirmacaoPedido);
         String[] permissoes = new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION
        };
        Permissoes.validarPermissoes(permissoes, this, 1);
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        @Override
        public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            for (int permissaoResultado : grantResults) {
                if (permissaoResultado == PackageManager.PERMISSION_DENIED) {

                } else {
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                        locationManager.requestLocationUpdates(
                                LocationManager.GPS_PROVIDER,
                                0,
                                0,
                                locationListener


                        );
                    }

                }
            }
        }

        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                Log.d("OnLocation", "onLocationChanged: "+ location.toString());
                double longi = location.getLongitude();
                double lati = location.getLatitude();
                Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
                try {
                    List<Address> lita  = geocoder.getFromLocation(lati, longi, 1);
                    if(lita != null && lita.size()>0){
                        enderecoGps = lita.get(0).getAddressLine(0);
                        Log.d("Endereco",  enderecoGps);

                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }


            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        };

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    0,
                    0,
                    locationListener


            );
        }

        DatabaseReference usuarioRef = RefUsuario
                .child( "usuarios")
                .child(UsuarioFirebase.getIdentificadorUsuario());

        usuarioRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Usuario usuario = dataSnapshot.getValue(Usuario.class);
               telemovel.setText(usuario.getTelefone());
               endereco.setText(enderecoGps);
               nomeUsuario = usuario.getNome();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        maquina.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

               if(isChecked == true){
                   troco.setVisibility(View.INVISIBLE);
                   layoutTroco.setVisibility(View.INVISIBLE);

               }
            }
        });

        dinheiro.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked == true){
                    troco.setVisibility(View.VISIBLE);
                    layoutTroco.setVisibility(View.VISIBLE);
                }
            }
        });

        dialogConfirmar.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Pedido novoPedido = new Pedido();
                novoPedido.setEndereco(endereco.getText().toString());
                novoPedido.setNome(nomeUsuario);
                novoPedido.setItens(listaCarrinho);
                if(maquina.isChecked()){
                    metodoPagamento = "Máquina Cartão";

                }else{
                    metodoPagamento = "Dinheiro";
                }
                novoPedido.setPagamento(metodoPagamento);
                novoPedido.setValor(totalCarrinho);
                novoPedido.setTelefone(telemovel.getText().toString());
                novoPedido.setTroco(troco.getText().toString());
                formaador = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                data = new Date();
                dataFormatada = formaador.format(data);
                novoPedido.setData(dataFormatada);
                novoPedido.setTokenUser(ConfiguraçaoFirebase.token());
                novoPedido.salvar();
                ItemPedido itemPedido = new ItemPedido();
                itemPedido.removerItensUsuario();

                enviarTokenAdmin();


            }
        });

        dialogConfirmar.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        AlertDialog dialog = dialogConfirmar.create();
        dialog.show();

    }


    public void inicializarComponentes(){

        recyclerView = findViewById(R.id.recyclerItemPedido);
        txtValorTotal = findViewById(R.id.textCarrinhoTotal);




    }


    public  void recupreraItensPedido(){
        DatabaseReference firebaseReference = ConfiguraçaoFirebase.getFirebase();

        RefItemPedido = firebaseReference.child("itemPedido")
                .child(UsuarioFirebase.getIdentificadorUsuario());
        RefItemPedido.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                listaItemPedido.clear();
                for (DataSnapshot itemPedido:dataSnapshot.getChildren()){
                    ItemPedido  item  = itemPedido.getValue(ItemPedido.class);
                    listaItemPedido.add(item);


                }
                Collections.reverse(listaItemPedido);
                adapterListaItensPedido.notifyDataSetChanged();


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    public void RecuperaValorTotal() {
        DatabaseReference firebaseReference = ConfiguraçaoFirebase.getFirebase();

        RefItemPedido = firebaseReference.child("itemPedido")
                .child(UsuarioFirebase.getIdentificadorUsuario());
        RefItemPedido.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                totalCarrinho = 0;
                listaCarrinho.clear();
                for (DataSnapshot itemPedido : dataSnapshot.getChildren()) {
                    ItemPedido item = itemPedido.getValue(ItemPedido.class);
                    totalCarrinho = totalCarrinho + item.getTotal();
                    listaCarrinho.add(item);
                }
                totalCarrinho = conversor.formtador(totalCarrinho);
                if(totalCarrinho !=0) {
                    txtValorTotal.setVisibility(View.VISIBLE);
                    txtValorTotal.setText("Total do Pedido: " + Double.toString(totalCarrinho) + " €");
                }else{
                    txtValorTotal.setVisibility(View.INVISIBLE);

                  startActivity(new Intent(Realizar_PedidoActivity.this, UserActivity.class));
                  finish();
                }



            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public  void enviarTokenAdmin(){
        DatabaseReference firebaseReference = ConfiguraçaoFirebase.getFirebase();
        RefToken = firebaseReference.child("AdminToken");
        RefToken.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot tokens: dataSnapshot.getChildren()){
                    MyFirebaseMessagingService.notificacao(tokens.getValue().toString(), 0);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

}
