package apadoca.com.br.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;


import apadoca.com.br.R;
import apadoca.com.br.helper.UsuarioFirebase;

public class Main_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_);


    }

    public void abrirTelaLogin(View view){
      startActivity(new Intent(this, LoginActivity.class));
    }
    public void abrirTelaCadastro(View view){
     startActivity(new Intent(this, CadastroActivity.class));
    }


}
