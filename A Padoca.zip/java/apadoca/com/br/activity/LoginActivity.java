package apadoca.com.br.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;

import apadoca.com.br.R;
import apadoca.com.br.helper.UsuarioFirebase;
import apadoca.com.br.helper.ConfiguraçaoFirebase;
import apadoca.com.br.model.Usuario;
import dmax.dialog.SpotsDialog;


public class LoginActivity extends AppCompatActivity {
    private TextInputEditText campoEmail, campoSenha;
    private FirebaseAuth autenticacao;
    private AlertDialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Acessar minha conta");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        campoEmail = findViewById(R.id.editLoginEmail);
        campoSenha = findViewById(R.id.editLoginSenha);
    }

    public void validarLoginUsuario(View view){



        String conteudoEmail = campoEmail.getText().toString();
        String conteudoSenha = campoSenha.getText().toString();

        if( !conteudoEmail.isEmpty()){
            if( !conteudoSenha.isEmpty()){
                Usuario usuario = new Usuario();
                usuario.setEmail( conteudoEmail);
                usuario.setSenha(conteudoSenha);
                logarUsuario( usuario);

            }else{
                Toast.makeText( LoginActivity.this,
                        "Preencha a Senha",
                        Toast.LENGTH_SHORT).show();
            }

        }else{

            Toast.makeText( LoginActivity.this,
                    "Preencha o E-mail",
                    Toast.LENGTH_SHORT).show();
        }
    }
    public void logarUsuario(Usuario usuario){
        dialog = new SpotsDialog.Builder().setContext(this).setMessage("Realizando Login").setCancelable(false).build();
        dialog.show();
        autenticacao = ConfiguraçaoFirebase.getFirebaseAutenticacao();
        autenticacao.signInWithEmailAndPassword(usuario.getEmail(), usuario.getSenha()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    UsuarioFirebase.redirecionaUsuarioLogado(LoginActivity.this);
                    dialog.dismiss();

                }else{
                    dialog.dismiss();
                    String erroExcecao = "";

                    try{
                        throw task.getException();
                    }catch (FirebaseAuthWeakPasswordException e){
                        erroExcecao = "Digite uma senha mais forte!";
                    }catch (FirebaseAuthInvalidCredentialsException e){
                        erroExcecao = "Por favor, digite um e-mail válido";
                    }catch (FirebaseAuthUserCollisionException e){
                        erroExcecao = "Este conta já foi cadastrada";
                    } catch (Exception e) {
                        erroExcecao = "ao fazer Login: "  + e.getMessage();
                        e.printStackTrace();
                    }

                    Toast.makeText(LoginActivity.this,
                            "Erro: " + erroExcecao ,
                            Toast.LENGTH_SHORT).show();

                }
            }
        });

    }

}
