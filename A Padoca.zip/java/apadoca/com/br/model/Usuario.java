package apadoca.com.br.model;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Exclude;

import apadoca.com.br.helper.ConfiguraçaoFirebase;
import apadoca.com.br.helper.UsuarioFirebase;

public class Usuario {

    private String id;
    private String Nome;
    private String Endereco;
    private String Telefone;
    private String Email;
    private String Senha;
    private String tipoUsuario;
    private String tokenUsuario;

    public Usuario() {
    }

    public  void salvar(){
        DatabaseReference firebaseReference = ConfiguraçaoFirebase.getFirebase();
        DatabaseReference usuarios = firebaseReference.child( "usuarios").child( getId());
        usuarios.setValue(this);
    }

    public void updateAdmin(String token){
        DatabaseReference firebaseReference = ConfiguraçaoFirebase.getFirebase();
        DatabaseReference usuarios = firebaseReference.child( "usuarios").
                child(UsuarioFirebase.getIdentificadorUsuario())
                .child("tokenUsuario");
        usuarios.setValue(token);
        AdminToken(token);
    }
    public void AdminToken(String token){
        DatabaseReference firebaseReference = ConfiguraçaoFirebase.getFirebase();
        DatabaseReference usuarios = firebaseReference.child( "AdminToken").
                child(token);
                usuarios.setValue(token);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getEndereco() {
        return Endereco;
    }

    public void setEndereco(String endereco) {
        Endereco = endereco;
    }

    public String getTelefone() {
        return Telefone;
    }

    public void setTelefone(String telefone) {
        Telefone = telefone;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    @Exclude
    public String getSenha() {
        return Senha;
    }

    public void setSenha(String senha) {
        Senha = senha;
    }

    public String getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(String tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }

    public String getTokenUsuario() {
        return tokenUsuario;
    }

    public void setTokenUsuario(String tokenUsuario) {
        this.tokenUsuario = tokenUsuario;
    }


}
