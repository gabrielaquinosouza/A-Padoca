package apadoca.com.br.model;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;

import java.io.Serializable;

import apadoca.com.br.helper.ConfiguraçaoFirebase;
import apadoca.com.br.helper.UsuarioFirebase;

public class ItemPedido implements Serializable {

    private String idProduto;
    private String nomeProduto;
    private int quantidade;
    private String obrservacoes;
    private double total;
    private double PrecoUnico;

    public ItemPedido() {
    }


    public void removerItemPedido(){
        DatabaseReference itemRefe = ConfiguraçaoFirebase.getFirebase().child("itemPedido")
                .child(UsuarioFirebase.getIdentificadorUsuario()).child(getIdProduto());
        itemRefe.removeValue();
    }
    public void removerItensUsuario(){
        DatabaseReference itemRefe = ConfiguraçaoFirebase.getFirebase().child("itemPedido")
                .child(UsuarioFirebase.getIdentificadorUsuario());
        itemRefe.removeValue();

    }
    public void Salvar() {


    DatabaseReference firebaseReference = ConfiguraçaoFirebase.getFirebase();
    DatabaseReference itempedido = firebaseReference.child("itemPedido")
            .child(UsuarioFirebase.getIdentificadorUsuario()).child(getIdProduto());
        itempedido.setValue(this);

}
    public double getPrecoUnico() {
        return PrecoUnico;
    }

    public void setPrecoUnico(double precoUnico) {
        PrecoUnico = precoUnico;
    }

    public String getIdProduto() {
        return idProduto;
    }

    public void setIdProduto(String idProduto) {
        this.idProduto = idProduto;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getObrservacoes() {
        return obrservacoes;
    }

    public void setObrservacoes(String obrservacoes) {
        this.obrservacoes = obrservacoes;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
}
