package apadoca.com.br.model;

import android.app.Activity;
import android.app.AlertDialog;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.storage.StorageReference;

import java.io.Serializable;

import apadoca.com.br.helper.ConfiguraçaoFirebase;
import dmax.dialog.SpotsDialog;

public class Produto implements Serializable {

    private AlertDialog dialog;
    private String id;
    private String categoria;
    private String nome;
    private String descricao;
    private double valor;
    private String imagem;
    private StorageReference storage;


    public Produto() {
        DatabaseReference produtoRefe = ConfiguraçaoFirebase.getFirebase().child("meus_produtos");
        setId(produtoRefe.push().getKey());
    }

    public  void  salvar(){
        DatabaseReference produtoRefe = ConfiguraçaoFirebase.getFirebase().child("meus_produtos");
        produtoRefe.child( getId()).setValue(this);
        salvarProdutoPublico();

    }

    public  void  salvarProdutoPublico(){
        DatabaseReference produtoRefe = ConfiguraçaoFirebase.getFirebase().child("Produtos");
        produtoRefe.child( getCategoria() ).child(getId()).setValue(this);

    }

    public  void removerProduto(Activity activity){
        dialog = new SpotsDialog.Builder().setContext(activity).setMessage("Removendo Produto").setCancelable(false).build();
        dialog.show();

        DatabaseReference produtoRefe = ConfiguraçaoFirebase.getFirebase().child("meus_produtos").child(getId());
        produtoRefe.removeValue();
        removerProdutoPublico();
        storage = ConfiguraçaoFirebase.getFirebaseStorage();
        StorageReference imagemProduto = storage.child( "imagens")
                .child( "Produtos").child( getId());
        imagemProduto.delete();
        dialog.dismiss();
    }

    public  void removerProdutoPublico(){

        DatabaseReference produtoRefe = ConfiguraçaoFirebase.getFirebase().child("Produtos").child( getCategoria()).child(getId());
        produtoRefe.removeValue();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }
}
