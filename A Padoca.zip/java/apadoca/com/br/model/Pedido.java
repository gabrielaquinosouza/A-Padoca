package apadoca.com.br.model;

import android.os.Build;

import androidx.annotation.RequiresApi;

import com.google.firebase.database.DatabaseReference;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import apadoca.com.br.helper.ConfiguraçaoFirebase;
import apadoca.com.br.helper.UsuarioFirebase;


public class Pedido  implements Serializable {

    private String idPedido;
    private String nome;
    private String pagamento;
    private double valor;
    private String Telefone;
    private String Endereco;
    private List<ItemPedido> itens;
    private String Troco;
    private String status = "Aguardando Confirmação";
    private String data;
    private String idUsuario = UsuarioFirebase.getIdentificadorUsuario();

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }


    private String tokenUser;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public void pedido_status(){
        DatabaseReference pedidoRef = ConfiguraçaoFirebase.getFirebase().child("pedido_status").child(getStatus());
        pedidoRef.child( getIdPedido()).setValue(this);
    }
    public void meus_pedidos_status(){
        DatabaseReference pedidoRef = ConfiguraçaoFirebase.getFirebase().child("meus_pedidos_status")
                .child(UsuarioFirebase.getIdentificadorUsuario()).child(getStatus());
        pedidoRef.child( getIdPedido()).setValue(this);
    }
    public void salvar(){
        DatabaseReference pedidoRef = ConfiguraçaoFirebase.getFirebase().child("pedidos");
        pedidoRef.child( getIdPedido()).setValue(this);
        salvarMeusPedidos();
        pedido_status();
        meus_pedidos_status();
    }

    public void salvarMeusPedidos(){
        DatabaseReference pedidoRef = ConfiguraçaoFirebase.getFirebase().child("meus_pedidos")
                .child(UsuarioFirebase.getIdentificadorUsuario());
        pedidoRef.child( getIdPedido()).setValue(this);

    }

    public void updatePedidos ( String idPedido, String status, String idUsuario){
        DatabaseReference pedidoRef = ConfiguraçaoFirebase.getFirebase().
                child("pedidos").
                child(idPedido).child("status");
        pedidoRef.setValue(status);
        updateMeusPedidos(idPedido, status, idUsuario);
    }

    public void updateMeusPedidos(String idPedido, String status, String idUsuario){
        DatabaseReference pedidoRef = ConfiguraçaoFirebase.getFirebase().child("meus_pedidos")
                .child(idUsuario).child( idPedido).child("status");
        pedidoRef.setValue(status);
    }

    public void updatePedidoStatus(String idPedido, String status_atual, String novo_status, String idUsuario, Pedido pedido){
        DatabaseReference pedidoRef = ConfiguraçaoFirebase.getFirebase().child("pedido_status").child(status_atual);
        pedidoRef.child( idPedido ).removeValue();

        DatabaseReference pedidoRef1 = ConfiguraçaoFirebase.getFirebase().child("pedido_status").child(novo_status);
        pedidoRef1.child( idPedido).setValue(pedido);

        DatabaseReference pedidoRef2 = ConfiguraçaoFirebase.getFirebase().child("meus_pedidos_status")
                .child(idUsuario).child(status_atual);
        pedidoRef2.child( idPedido).removeValue();

        DatabaseReference pedidoRef3 = ConfiguraçaoFirebase.getFirebase().child("meus_pedidos_status")
                .child(idUsuario).child(novo_status);
        pedidoRef3.child( idPedido).setValue(pedido);


    }




    public Pedido() {
        DatabaseReference pedidoRefe = ConfiguraçaoFirebase.getFirebase().child("pedidos");
        setIdPedido(pedidoRefe.push().getKey());
    }

    public String getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(String idPedido) {
        this.idPedido = idPedido;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPagamento() {
        return pagamento;
    }

    public void setPagamento(String pagamento) {
        this.pagamento = pagamento;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getTelefone() {
        return Telefone;
    }

    public void setTelefone(String telefone) {
        Telefone = telefone;
    }

    public String getEndereco() {
        return Endereco;
    }

    public void setEndereco(String endereco) {
        Endereco = endereco;
    }

    public List<ItemPedido> getItens() {
        return itens;
    }

    public void setItens(List<ItemPedido> itens) {
        this.itens = itens;
    }

    public String getTroco() {
        return Troco;
    }

    public void setTroco(String troco) {
        Troco = troco;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    public String getTokenUser() {
        return tokenUser;
    }

    public void setTokenUser(String tokenUser) {
        this.tokenUser = tokenUser;
    }

}
