package apadoca.com.br.Interfaces;

import com.google.android.gms.common.util.Strings;
import com.google.gson.JsonObject;

import org.json.JSONObject;

import apadoca.com.br.R;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface DataService {
     String token_server = "AAAAWU-fG2Q:APA91bFCcA0kVlXe9qIgTEQghQKe7wfGGyjFjO3r7KvpFOA9avGvonLGBRgbf7IS6lCBrdFFb8Y1Xue-TZ6DO4l7mRmBiMcEBERK_4v0BvGbvVCj6k_xKBSamzegBueVzvSVfhjXK_-g";
@Headers({
        "Authorization: key="+ token_server,
        "Content-Type: application/json"
})
    @POST("fcm/send")
    Call<JsonObject> mandarNotificacao (@Body JsonObject notificacao);
}
